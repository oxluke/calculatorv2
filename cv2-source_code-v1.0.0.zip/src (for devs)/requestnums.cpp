#include <iostream>


using namespace std;


double num1;
double num2;


void requestNums()
{
    cout << "Please provide the first number. \n";
    cin >> num1;

    cout << "Please provide the second number. \n";
    cin >> num2;
}