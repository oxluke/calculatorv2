// Include built-in <iostream> header file
#include <iostream>


// Include custom-made header files
#include "add.cpp"
#include "subtr.cpp"
#include "multip.cpp"
#include "divid.cpp"

#include "requestnums.cpp"


// Use namespace std to remove need of "std::"
using namespace std;


// Initialize ans and memory variables
double ans;
double memory;


// CalculatorV2 main function
int main()
{
    string op;

    cout << "Hello! Please select the operator you'd like to use. \n"       // Request operator
         << "(+, -, *, /) \n";
    
    cin >> op;
    
    if (op == "+" || op == "-" || op == "*" || op == "/")                   // Request num1 and num2
    {
        requestNums();
    }


    if (op == "+")                  // Provide sum of num1 and num2
    {
        ans = add(num1, num2);
    }
    else if (op == "-")             // Provide difference of num1 and num2
    {
        ans = subtr(num1, num2);
    }
    else if (op == "*")             // Provide product of num1 and num2
    {
        ans = multip(num1, num2);
    }
    else if (op == "/")             // Provide quotient of num1 and num2
    {
        ans = divid(num1, num2);
    }
    

    cout << num1 << " " << op << " " << num2 << " = " << ans << "\n";       // Print out the equation + answer
    system("pause");


}