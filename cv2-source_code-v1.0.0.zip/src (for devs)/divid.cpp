double divid(double x, double y)
{
    return x / y;
}
